def elsok_osszege(lista:list, szám:int):
    összeg = 0
    if szám <= 0 or szám > len(lista):
        return -1
    else:
        for i in range(szám):
            összeg += lista[i]
        return összeg

def kiír(k:int, osszeg:int):
    if osszeg == -1:
        print("„Hibás a megadott k érték.")
    else:
        print("Az első <", k, "> elem összege: <", osszeg, ">", sep="")

def main():
    x = [5, 1, -9, 7, 5, -13, 8, 22]
    k = int(input("k: "))

    a = elsok_osszege(x, k)
    kiír(k, a)

main()