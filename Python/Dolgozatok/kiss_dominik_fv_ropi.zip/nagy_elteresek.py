homersekletek = [4, -1, 2, 2, 3, 8, 5, -1, 1, 4, 0, -2, -1, 6, 5]
n = len(homersekletek)
nagyok = []

for i in range(1, n):
    if homersekletek[i]+2 < homersekletek[0] and homersekletek[i] not in nagyok:
        nagyok.append(homersekletek[i])
    elif homersekletek[i]-2 > homersekletek[0] and homersekletek[i] not in nagyok:
        nagyok.append(homersekletek[i])

for x in nagyok:
    print(x, end=" ")