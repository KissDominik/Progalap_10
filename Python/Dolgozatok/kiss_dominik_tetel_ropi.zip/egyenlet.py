n = int(input())

lista = []

for i in range(n):
    lista.append(int(input()))

maximum = lista[0]
index = 0

for i in range(1, n):
    if lista[i] > maximum:
        maximum = lista[i]
        index = i

print(index + 1, maximum)