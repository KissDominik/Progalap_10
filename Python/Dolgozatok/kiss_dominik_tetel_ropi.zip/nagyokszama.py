lista = [7, -3, 10, 27, 92, 23, 18, 73, -21, 12, -9, 30, -4, 5]
n = len(lista)
nagyobb_es_paratlan_db = 0

for i in range(n):
    if lista[i] > lista[0] and lista[i] % 2 != 0:
        nagyobb_es_paratlan_db += 1
        
print(nagyobb_es_paratlan_db)