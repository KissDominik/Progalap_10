a = input("osztály neve:")
ap = int(input("osztály pontszáma:"))

if a == "a":
    print("Nyertek a közgazdászok! Csak", 60 - ap, "pontot vesztettek!")
elif a == "b":
    print("győztek a gazdinfósok! Csak", 60 - ap, "pontot vesztettek!")
else:
    print("Infósok a legjobbak! Csak", 60 - ap, "pontot vesztettek!")