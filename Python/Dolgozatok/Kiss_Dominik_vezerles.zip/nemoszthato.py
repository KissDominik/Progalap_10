n = int(input("n: "))

for i in range(101):
    if i % n != 0:
        print(i, end=" ")