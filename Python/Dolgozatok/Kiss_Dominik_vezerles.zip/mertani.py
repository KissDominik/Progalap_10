a = int(input("a: "))
q = int(input("q: "))

for i in range(51):
    print(a, end=" ")
    a = a * q