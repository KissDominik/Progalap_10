a = float(input("diák1 eredménye: "))
b = float(input("diák2 eredménye: "))
c = float(input("diák3 eredménye: "))

while (a + b + c) // 3 < 80:
    print("tanulni kéne! Újra írjuk!")
    a = int(input("diák1 eredménye: "))
    b = int(input("diák2 eredménye: "))
    c = int(input("diák3 eredménye: "))

print("átlag:", round((a + b + c) / 3, 2))